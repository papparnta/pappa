/******** MODIFICHE 27 Aprile 2002 ************************************
- i_biquad:   cambiato il modo di calcolare il numero di bit effettivo
              dell'esponente. Adesso non deve essere pi� passato il
		  parametro <n>.


***********************************************************************/

#include<stdlib.h>
#include<pari.h>

#define  macro1(t)  ((((t)[lgefint(t)-1]) & 12)>>2) // ((t mod 4)/4) mod 4  , t tipo GEN

#define  gap(u,v)   (abs(lgefint((GEN)u[2])-lgefint((GEN)v[2]))-abs(lgefint((GEN)u[1])-lgefint((GEN)v[1])))



// In questa libreria x,y sono elementi di Z[i],
// cio� sono della forma
// x=x[1]+x[2]i
// y=y[1]+y[2]i


//*******************************************
// Funzione per il calcolo della norma di x
//*******************************************

//GEN(t_INT) gnorm(GEN x)


//*********************************************
// Funzione per il calcolo del coniugato di x
//*********************************************

//GEN(t_COMPLEX) gconj(GEN x)


//**********************************
//  Funzione per il calcolo di x+y
//**********************************

GEN i_somma(GEN x,GEN y,long prec){
	long ltop;
	GEN ris;
	ris=cgetg(3,t_COMPLEX);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	//(GEN)ris[1]=addii((GEN)x[1],(GEN)y[1]);
	//(GEN)ris[2]=addii((GEN)x[2],(GEN)y[2]);
	//outbeaut(x);
	//outbeaut(y);
	//outbeaut(ris);
	addiiz((GEN)x[1],(GEN)y[1],(GEN)ris[1]);
	addiiz((GEN)x[2],(GEN)y[2],(GEN)ris[2]);
	avma=ltop;
	return(ris);
}


//**********************************
//  Funzione per il calcolo di x-y
//**********************************

GEN i_diff(GEN x,GEN y,long prec){
	long ltop;
	GEN ris;
	ris=cgetg(3,t_COMPLEX);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	//(GEN)ris[1]=subii((GEN)x[1],(GEN)y[1]);
	//(GEN)ris[2]=subii((GEN)x[2],(GEN)y[2]);
	//outbeaut(x);
	//outbeaut(y);
	//outbeaut(ris);
	subiiz((GEN)x[1],(GEN)y[1],(GEN)ris[1]);
	subiiz((GEN)x[2],(GEN)y[2],(GEN)ris[2]);
	avma=ltop;
	return(ris);
}


//**********************************
//  Funzione per il calcolo di x*y
//**********************************

//GEN(t_COMPLEX) gmul(GEN x,GEN y)

//  Le funzioni precedenti sono tutte contenute nella
//  libreria di PARI, in quanto collegate ai tipi t_COMPLEX
//  Le seguenti funzioni sono state costruite, in quanto assenti.


//**********************************************
//  Funzione per il calcolo di x/y senza resto
//**********************************************

GEN i_div(GEN x,GEN y,long prec){
	long ltop;
	GEN ris,app;
	ris=cgetg(3,t_COMPLEX);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	app=gdiv(x,y);
	affii(ground((GEN)app[1]),(GEN)ris[1]);
	affii(ground((GEN)app[2]),(GEN)ris[2]);
	avma=ltop;
	return(ris);
}


//*************************************
// Funzione per il calcolo di x mod y
//*************************************

GEN i_mod(GEN x,GEN y,long prec){
	long ltop;
	GEN ris,phi,Ny;
	ris=cgetg(3,t_COMPLEX);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	//Nx=cgeti(prec);
	phi=cgetg(3,t_COMPLEX);
	phi[1]=lgeti(prec/2+1);  //nella libreria cubica non era diviso 2, l'ho cambiato!!!
	phi[2]=lgeti(prec/2+1);  //idem
	
	//gaffect(w_prod(x,w_coniug(y,prec),prec),phi); 
	Ny=addii(sqri((GEN)y[1]),sqri((GEN)y[2]));
	//Ny=gnorm(y);        //ok
	affii(gdivround(addii(mulii((GEN)x[1],(GEN)y[1]),mulii((GEN)x[2],(GEN)y[2])),Ny),(GEN)phi[1]);
	affii(gdivround(subii(mulii((GEN)x[2],(GEN)y[1]),mulii((GEN)x[1],(GEN)y[2])),Ny),(GEN)phi[2]);
	
	subiiz((GEN)x[1],subii(mulii((GEN)phi[1],(GEN)y[1]),mulii((GEN)phi[2],(GEN)y[2])),(GEN)ris[1]);
	subiiz((GEN)x[2],addii(mulii((GEN)phi[2],(GEN)y[1]),mulii((GEN)phi[1],(GEN)y[2])),(GEN)ris[2]);
	avma=ltop;
	return(ris);
}

/*
GEN i_mod2(GEN x,GEN y,long prec){
	long ltop;
	GEN ris,phi,app;
	ris=cgetg(3,t_COMPLEX);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	phi=cgetg(3,t_COMPLEX);
	phi[1]=lgeti(prec/2+1); //non era diviso 2!!
	phi[2]=lgeti(prec/2+1); //idem
	app=gdiv(x,y);
	affii(ground((GEN)app[1]),(GEN)phi[1]);
	affii(ground((GEN)app[2]),(GEN)phi[2]);

	gsubz(x,gmul(phi,y),ris);
	avma=ltop;
	return(ris);
}


// gcd(x,y)
// per ora non va fatto

GEN w_gcd(GEN x,GEN y,long prec){
	long ltop;
	GEN temp,xx,yy;
	yy=cgetg(3,t_VEC);
	yy[1]=lgeti(prec/2+1);
	yy[2]=lgeti(prec/2+1);
	ltop=avma;
	xx=cgetg(3,t_VEC);
	xx[1]=lgeti(prec/2+1);
	xx[2]=lgeti(prec/2+1);
	temp=cgetg(3,t_VEC);
	temp[1]=lgeti(prec/2+1);
	temp[2]=lgeti(prec/2+1);
	gaffect(x,xx);
	gaffect(y,temp);
	do{
		gaffect(temp,yy);
		gaffect(i_mod(xx,yy,prec),temp);
		gaffect(yy,xx);
	}while(!gegal(temp,flisexpr("[0,0]")));
	avma=ltop;
	return(yy);
}
*/

//***************************************************
// Funzione che trasforma x nel primario associato, 
// P(x), e restituisce l'esponente dell'i, unit� 
// associata, c(x), mod 4, c(x).
// x=i^c(x) P(x)
//***************************************************

short i_primario(GEN x,long prec){
	long ltop;
	short a,b;
	GEN temp;
	temp=cgeti(prec/2+1);
	ltop=avma;
	
	
//	l'if successivo verifica se 1+i|x, cio� se 2|x[1]+x[2]
	if (!(mpodd((GEN)x[1]) ^ mpodd((GEN)x[2]))) {
		printf("\n ATTENZIONE: impossibile trovare il primario associato, 1+i divide ");
		outbeaut(x);
		exit(EXIT_FAILURE);
	}
	
	switch(signe((GEN)x[1])){
		case -1: a=mod4(negi((GEN)x[1]));
			if(a) a=4-a;
			break;
		case  1: a=mod4((GEN)x[1]);break;
		case  0: a=0;
	}
	switch(signe((GEN)x[2])){
		case -1: b=mod4(negi((GEN)x[2]));
			if(b) b=4-b;	
			break;
		case  1: b=mod4((GEN)x[2]);break;
		case  0: b=0;
	}
	//grazie a queste istruzioni a e b appartengono a {0,1,2,3}
	//inoltre non potevo fare mod4 di interi negativi!!!

	//printf("\n >> a %d, b %d",a,b);
	
	switch(a){
		case 1: switch(b){
			case 0: avma=ltop; return(0);
			case 2: setsigne((GEN)x[1],-signe((GEN)x[1])); 
				setsigne((GEN)x[2],-signe((GEN)x[2])); 
				avma=ltop;
				return(2);
			}
		case 3: switch(b){
			case 2: avma=ltop; return(0);
			case 0: //x=gneg(x);
				setsigne((GEN)x[1],-signe((GEN)x[1])); 
				setsigne((GEN)x[2],-signe((GEN)x[2])); 
				avma=ltop;
				return(2);
			}
		case 2: switch(b){
			case 3: affii(negi((GEN)x[1]),temp);
				(GEN)x[1]=(GEN)x[2];
				(GEN)x[2]=temp;
				//affii((GEN)x[2],(GEN)x[1]);
				//affii(temp,(GEN)x[2]);
				avma=ltop;
				return(1);
			case 1: affii(negi((GEN)x[2]),temp);
				(GEN)x[2]=(GEN)x[1];
				(GEN)x[1]=temp;
				//affii((GEN)x[1],(GEN)x[2]);
				//affii(temp,(GEN)x[1]);
				avma=ltop;
				return(3);
			}
		case 0: switch(b){
			case 1: affii(negi((GEN)x[1]),temp);
				(GEN)x[1]=(GEN)x[2];
				(GEN)x[2]=temp;
				avma=ltop;
				return(1);
			case 3: affii(negi((GEN)x[2]),temp);
				(GEN)x[2]=(GEN)x[1];
				(GEN)x[1]=temp;
				//gaffect((GEN)x[1],(GEN)x[2]);
				avma=ltop;
				return(3);
			}
	}
	avma=ltop;
	return(5);
}


// ********************************************************
// Funzione per calcolare il residuo biquadratico tramite 
// l'esponenziale x^(Ny-1/4) mod y, utilizzando il 
// metodo dei quadrati successivi
// ********************************************************

GEN i_biquad(GEN x,GEN y,long prec){
	long ltop,j,memstart,lb,n,ly;
	unsigned long m,u;
	GEN ris,b;
	ris=cgetg(3,t_COMPLEX);
	ris[1]=lgeti(prec+1);
	ris[2]=lgeti(prec+1);
	ltop=avma;
	gaffect(flisexpr("1+0*I"),ris);
	b=cgeti(prec);
	//divisz(subii(gnorm(y),gun),4,b);
	affii(shifti(subii(gnorm(y),gun),-2),b);
	lb=lgefint(b);
      if (lb==2) return (ris);    // caso in cui l'esponente � uguale a 0
      ly = BITS_IN_LONG+1; m=HIGHBIT; u=b[2];
      while (!(m & u)) { m>>=1; ly--; }
      n = ly+((lb-3)<<TWOPOTBITS_IN_LONG);	
	memstart=avma;
	for(j=n-1;j>=0;j--){
		avma=memstart;
		gaffect(i_mod(gsqr(ris),y,prec),ris);
		if (bittest(b,j)) gaffect(i_mod(gmul(ris,x),y,prec),ris);
	}
	avma=ltop;
	return(ris);
}

//                          [    x    ]
//Funzione per calcolare    [ ------- ]
//                          [    y    ]3

short i_rbiquad(GEN x,GEN y,long prec){
	long ltop1,r1,r2,t,esp,tempo[4],flag;
	short k,ris,j;

	GEN lambda,yy,temp,esp_k_j,temp2,temp3;
	
	ltop1=avma;
	lambda=cgetg(3,t_COMPLEX);
	lambda[1]=lgeti(prec/2+1);
	lambda[2]=lgeti(prec/2+1);

	yy=cgetg(3,t_COMPLEX);
	yy[1]=lgeti(prec/2+1);
	yy[2]=lgeti(prec/2+1);

	temp=cgetg(3,t_COMPLEX);
	temp[1]=lgeti(prec/2+1);
	temp[2]=lgeti(prec/2+1);

	esp_k_j=cgeti(4*prec);
	temp2=cgeti(prec/2+1);
	temp3=cgeti(prec/2+1);
	
	affii(gzero,esp_k_j);
	esp=0;
	 //for(j=0;j<4;j++) tempo[j]=0;
	
	if (!signe((GEN)y[1]) && !signe((GEN)y[2])) {   // verifico se al denominatore del residuo ho y= 0+0i
		if(!signe((GEN)x[2]) && is_pm1((GEN)x[1]))
			switch(signe((GEN)x[1])) {
				case -1: return(2);  // x=-1+0i
				case 1: return(0);   // x= 1+0i 
			}
		if(!signe((GEN)x[1]) && is_pm1((GEN)x[2]))
			switch(signe((GEN)x[2])) {
				case -1: return(3);  // x= 0-i
				case 1: return(1);   // x= 0+i
			}
		return(5);                        // x qualsiasi: l'esponente 5 indica il residuo biq pari a 0
	}
	gaffect(x,yy);
	gaffect(y,lambda);
	//ho invertito x ed y per trovarmeli giusti al primo ciclo	
	
	
	 //timer2();
	
	i_primario(lambda,prec); 
	
	//temp=i_mod(yy,lambda,prec);
	flag=0;
	 
	 //printf("\n tempo--  %d\n",timer2());
	do{
		 //timer2();
		//temp=i_mod(yy,lambda,prec);
		 //tempo[0]=tempo[0]+timer2();
		//printf("\n provaaa %d %d %d %d\n",lgefint((GEN)yy[2]),lgefint((GEN)lambda[2]),lgefint((GEN)yy[1]),lgefint((GEN)lambda[1]));
		//outbeaut(lambda);
		//outbeaut(yy);
		//printf("\n gap %d\n",gap(yy,lambda));
		//if(flag)
		//outbeaut(binaire((GEN)yy[1]));
		//outbeaut(binaire((GEN)lambda[1]));
		//outbeaut(binaire((GEN)yy[2]));
		//outbeaut(binaire((GEN)lambda[2]));
		//printf("\n");
		/*
		switch(signe((GEN)yy[1])){
			case  0: if (!signe((GEN)lambda[1]))
					switch(signe((GEN)lambda[2])){
						case  1: temp=i_diff(yy,lambda,prec); break;
						case -1: temp=i_somma(yy,lambda,prec); break;
					};
			case  1: switch(signe((GEN)yy[2])){
				case  0: if (!signe((GEN)lambda[2]))
						switch(signe((GEN)lambda[1])){
							case  1: temp=i_diff(yy,lambda,prec); break;
							case -1: temp=i_somma(yy,lambda,prec); break;
						};
				case  1: switch(signe((GEN)lambda[1])){
					case  1: switch(signe((GEN)lambda[2])){
						case  1:case 0: temp=i_diff(yy,lambda,prec); break;
						case -1: if(gap(yy,lambda)<0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
					} break;
					case -1: switch(signe((GEN)lambda[2])){
						case  1: if(gap(yy,lambda)>0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
						case -1:case 0: temp=i_somma(yy,lambda,prec); break;
					} break;
				} break;
				case -1: switch(signe((GEN)lambda[1])){
					case  1: switch(signe((GEN)lambda[2])){
						case  1: if(gap(yy,lambda)<0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
						case -1:case 0: temp=i_diff(yy,lambda,prec); break;
					} break;
					case -1: switch(signe((GEN)lambda[2])){
						case  1:case 0: temp=i_somma(yy,lambda,prec); break;
						case -1: if(gap(yy,lambda)>0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
					} break;
				} break;
			} break;
			case -1: switch(signe((GEN)yy[2])){
				case  0: if (!signe((GEN)lambda[2]))
						switch(signe((GEN)lambda[1])){
							case  1: temp=i_somma(yy,lambda,prec); break;
							case -1: temp=i_diff(yy,lambda,prec); break;
					};
				case  1: switch(signe((GEN)lambda[1])){
					case  1: switch(signe((GEN)lambda[2])){
						case  1: if(gap(yy,lambda)>0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
						case -1:case 0: temp=i_somma(yy,lambda,prec); break;
					} break;
					case -1: switch(signe((GEN)lambda[2])){
						case  1:case 0: temp=i_diff(yy,lambda,prec); break;
						case -1: if(gap(yy,lambda)<0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
					} break;
				} break;
				case -1: switch(signe((GEN)lambda[1])){
					case  1: switch(signe((GEN)lambda[2])){
						case  1:case 0: temp=i_somma(yy,lambda,prec); break;
						case -1: if(gap(yy,lambda)>0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
					} break;
					case -1: switch(signe((GEN)lambda[2])){
						case  1: if(gap(yy,lambda)<0) temp=i_somma(yy,lambda,prec);
								else temp=i_diff(yy,lambda,prec); break;
						case -1:case 0: temp=i_diff(yy,lambda,prec); break;
					} break;
				} break;
			} break;
		};*/
		//flag++;
		if(((((GEN)yy[1])[lgefint((GEN)yy[1])-1]) ^ (((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]))&2)
			if(signe((GEN)yy[1])==signe((GEN)lambda[1])) temp=i_somma(yy,lambda,prec);
			else temp=i_diff(yy,lambda,prec);
		else if(signe((GEN)yy[1])==signe((GEN)lambda[1])) temp=i_diff(yy,lambda,prec);
			else temp=i_somma(yy,lambda,prec);
		
		yy=lambda;
		lambda=temp;
		//printf("\n provaaa3\n");
		//outbeaut(lambda);
		//outbeaut(yy);
		if(!(signe((GEN)lambda[1]) || signe((GEN)lambda[2]))) return(5);
		
		r1=vali((GEN)lambda[1]);
		
		if(r1){
			r2=vali((GEN)lambda[2]);
			if(r2){
				if(!(signe((GEN)lambda[1]) && signe((GEN)lambda[2]))) t=(r1>r2)? r1: r2;
				else t=(r1<r2)? r1: r2;
				(GEN)lambda[1]=shifti((GEN)lambda[1],-t);
				(GEN)lambda[2]=shifti((GEN)lambda[2],-t);
				switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 6) {
					case 2: switch(signe((GEN)yy[2])){
						case  1: esp-=t; break;
						case -1: esp+=t; break;
						} break;
					case 4: esp+=(t<<1); break;
					case 6: switch(signe((GEN)yy[2])){
						case  1: esp+=t; break;
						case -1: esp-=t; break;
						} break; 
					case 0: break;
				}
			}	
		}
		 //tempo[1]=tempo[1]+timer2();
		if( mod2((GEN)lambda[1]) & mod2((GEN)lambda[2]) ){
		//if(!(mpodd((GEN)lambda[1]) ^ mpodd((GEN)lambda[2]))){   //verifica se hanno la stessa parit�
			temp3=shifti(addii((GEN)lambda[1],(GEN)lambda[2]),-1);
			(GEN)lambda[2]=shifti(subii((GEN)lambda[2],(GEN)lambda[1]),-1);
			(GEN)lambda[1]=temp3;
			switch(signe((GEN)yy[2])){
				case -1: switch(signe((GEN)yy[1])){
						case -1: esp+=macro1((GEN)yy[2])-macro1((GEN)yy[1])-1; break;
						case  1: esp+=macro1((GEN)yy[2])+macro1((GEN)yy[1]); break;
				} break;
				case  1: switch(signe((GEN)yy[1])){
						case -1: switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 2){
							case 0: esp-=(macro1((GEN)yy[2])+macro1((GEN)yy[1])+1); break;
							case 2: esp-=(macro1((GEN)yy[2])+macro1((GEN)yy[1])+2); break;
						} break;
						case  1: switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 2){
							case 0: esp+=macro1((GEN)yy[1])-macro1((GEN)yy[2]); break;
							case 2: esp+=macro1((GEN)yy[1])-macro1((GEN)yy[2])-1; break;
						} break;
				} break;
				case 0: switch(signe((GEN)yy[1])){
						case -1: esp-=(macro1((GEN)yy[1])+1); break;
						case  1: esp+=macro1((GEN)yy[1]); break;
				} break;
			}
		}
		 //tempo[2]=tempo[2]+timer2();
		k=i_primario(lambda,prec);
		 //timer2();
		switch((((GEN)yy[1])[lgefint((GEN)yy[1])-1]) & 7) {
					case 1: switch(signe((GEN)yy[1])){
						case  1: break;
						case -1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=k; break;
								case 3: esp+=(k-2); break;
							} break;
						} break;
					case 3: switch(signe((GEN)yy[1])){
						case  1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp-=k; break;
								case 3: esp+=(2-k); break;
							} break;
						case -1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=(k<<1); break;
								case 3: esp+=((k-2)<<1); break;
							} break;
						} break;
					case 5: switch(signe((GEN)yy[1])){
						case  1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=(k<<1); break;
								case 3: esp+=((k-2)<<1); break;
							} break;
						case -1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp-=k; break;
								case 3: esp+=(2-k); break;
							} break;
						} break;
					case 7: switch(signe((GEN)yy[1])){
						case  1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=k; break;
								case 3: esp+=(k-2); break;
							} break;
						case  -1: break;
						} break;
		}
		 //tempo[3]=tempo[3]+timer2();
	}while (signe((GEN)lambda[2]) || !is_pm1((GEN)lambda[1]));
	 //for(j=0;j<4;j++) printf("\n Tempi%d   %d%",j,tempo[j]);
	//printf("\n Tot %d",flag);
	avma=ltop1;
	return(esp&3);
}

/*
//                          [    x    ]
//Funzione per calcolare    [ ------- ]
//                          [    y    ]3

short i_rbiquad2(GEN x,GEN y,long prec){
	long ltop1,r1,r2,t,esp,esp1,esp2;
	short k,ris;

	GEN lambda,yy,temp,esp_k_j,temp2,temp3;
	
	ltop1=avma;
	lambda=cgetg(3,t_COMPLEX);
	lambda[1]=lgeti(prec/2+1);
	lambda[2]=lgeti(prec/2+1);

	yy=cgetg(3,t_COMPLEX);
	yy[1]=lgeti(prec/2+1);
	yy[2]=lgeti(prec/2+1);

	temp=cgetg(3,t_COMPLEX);
	temp[1]=lgeti(prec/2+1);
	temp[2]=lgeti(prec/2+1);

	esp_k_j=cgeti(4*prec);
	temp2=cgeti(prec/2+1);
	temp3=cgeti(prec/2+1);
	
	affii(gzero,esp_k_j);
	esp=0;
	//esp1=0;
	//esp2=0;
	
	if (!signe((GEN)y[1]) && !signe((GEN)y[2])) {   // verifico se al denominatore del residuo ho y= 0+0i
		if(!signe((GEN)x[2]) && is_pm1((GEN)x[1]))
			switch(signe((GEN)x[1])) {
				case -1: return(2);  // x=-1+0i
				case 1: return(0);   // x= 1+0i 
			}
		if(!signe((GEN)x[1]) && is_pm1((GEN)x[2]))
			switch(signe((GEN)x[2])) {
				case -1: return(3);  // x= 0-i
				case 1: return(1);   // x= 0+i
			}
		return(5);                        // x qualsiasi: l'esponente 5 indica il residuo biq pari a 0
	}
	
	gaffect(x,yy);
	gaffect(y,lambda);
	//ho invertito x ed y per trovarmeli giusti al primo ciclo	
	i_primario(lambda,prec); 

	do{		
		temp=i_mod(yy,lambda,prec);
		yy=lambda;
		lambda=temp;
		//gaffect(lambda,yy);
		//gaffect(temp,lambda);
		printf("\n aleee\n");
		outbeaut(temp);
		outbeaut((GEN)temp[1]);
		outbeaut((GEN)temp[2]);
		
		if(!(signe((GEN)lambda[1]) || signe((GEN)lambda[2]))) return(5);
		r1=vali((GEN)lambda[1]);
		if(r1){
			r2=vali((GEN)lambda[2]);
			if(r2){
				if(!(signe((GEN)lambda[1]) && signe((GEN)lambda[2]))) t=(r1>r2)? r1: r2;
				else t=(r1<r2)? r1: r2;
				printf("\n punto00 %d %d %d\n",r1,r2,t);
				(GEN)lambda[1]=shifti((GEN)lambda[1],-t);
				(GEN)lambda[2]=shifti((GEN)lambda[2],-t);
				switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 6) {
					case 2: switch(signe((GEN)yy[2])){
						case  1: esp-=t; break;
						case -1: esp+=t; break;
						} break;
					case 4: esp+=(t<<1); break;
					case 6: switch(signe((GEN)yy[2])){
						case  1: esp+=t; break;
						case -1: esp-=t; break;
						} break; 
					case 0: break;
				}
				//addsii(esp1,esp_k_j,esp_k_j);
				printf("\n punto0 \n");
			}	
		}
		printf("\n esp %d\n",esp);
		
		//subiiz((GEN)yy[1],gun,temp2);
		outbeaut(lambda);
		
		//qui va modificato xch� entro nel ciclo se e solo se sono entrambi dispari
		//in quanto non possono essere pari dal ciclo precedente --> utilizzo l'ultimo bit!
		if(!(mpodd((GEN)lambda[1]) ^ mpodd((GEN)lambda[2]))){   //verifica se hanno la stessa parit�
			temp3=shifti(addii((GEN)lambda[1],(GEN)lambda[2]),-1);
			(GEN)lambda[2]=shifti(subii((GEN)lambda[2],(GEN)lambda[1]),-1);
			(GEN)lambda[1]=temp3;
			printf("\n punto1\n");
			switch(signe((GEN)yy[2])){
				case -1: switch(signe((GEN)yy[1])){
						case -1: esp+=macro1((GEN)yy[2])-macro1((GEN)yy[1])-1; break;
						case  1: esp+=macro1((GEN)yy[2])+macro1((GEN)yy[1]); break;
				} break;
				case  1: switch(signe((GEN)yy[1])){
						case -1: switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 2){
							case 0: esp-=(macro1((GEN)yy[2])+macro1((GEN)yy[1])+1); break;
							case 2: esp-=(macro1((GEN)yy[2])+macro1((GEN)yy[1])+2); break;
						} break;
						case  1: switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 2){
							case 0: printf("\n sto qui %d, %d, %d\n",macro1((GEN)yy[1]),macro1((GEN)yy[2]),esp);
								esp+=macro1((GEN)yy[1])-macro1((GEN)yy[2]); 
								printf("\n espo %d\n",esp);
								break;
							case 2: esp+=macro1((GEN)yy[1])-macro1((GEN)yy[2])-1; break;
						} break;
				} break;
				case 0: switch(signe((GEN)yy[1])){
						case -1: esp-=(macro1((GEN)yy[1])+1); break;
						case  1: esp+=macro1((GEN)yy[1]); break;
				} break;
			}
/*			switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 2) {
				case 0: addiiz(shifti(subii(temp2,(GEN)yy[2]),-2),esp_k_j,esp_k_j); break;
				case 2: addiiz(shifti(subii(temp2,addis((GEN)yy[2],4)),-2),esp_k_j,esp_k_j); break;
			}
			*/
//			addiiz(shifti(subii(temp2,addii((GEN)yy[2],gsqr((GEN)yy[2]))),-2),esp_k_j,esp_k_j);
			//addsii(esp,esp_k_j,esp_k_j);
/*			printf("\n punto2\n");
		}
		printf("\n esp %d\n",esp);
		outbeaut(lambda);
		k=i_primario(lambda,prec);
		outbeaut(lambda);
		printf("\n punto3 %d\n",k);
		switch((((GEN)yy[1])[lgefint((GEN)yy[1])-1]) & 7) {
					case 1: switch(signe((GEN)yy[1])){
						case  1: break;
						case -1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=k; break;
								case 3: esp+=(k-2); break;
							} break;
						} break;
					case 3: switch(signe((GEN)yy[1])){
						case  1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp-=k; break;
								case 3: esp+=(2-k); break;
							} break;
						case -1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=(k<<1); break;
								case 3: esp+=((k-2)<<1); break;
							} break;
						} break;
					case 5: switch(signe((GEN)yy[1])){
						case  1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=(k<<1); break;
								case 3: esp+=((k-2)<<1); break;
							} break;
						case -1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp-=k; break;
								case 3: esp+=(2-k); break;
							} break;
						} break;
					case 7: switch(signe((GEN)yy[1])){
						case  1: switch(((((GEN)lambda[1])[lgefint((GEN)lambda[1])-1]) & 3)^(1-signe((GEN)lambda[1]))){
								case 1: esp+=k; break;
								case 3: esp+=(k-2); break;
							} break;
						case  -1: break;
						} break;
		}
		//addsii(esp2,esp_k_j,esp_k_j);
//		subiiz(esp_k_j,mulii(subsi(k+1,(GEN)lambda[1]),shifti(temp2,-1)),esp_k_j);
		printf("\n punto4\n");
		printf("\n esp %d\n",esp);
	}while (signe((GEN)lambda[2]) || !is_pm1((GEN)lambda[1]));
	printf("\n fine\n");
/*	switch(signe(esp_k_j)){
		case -1:ris=mod4(negi(esp_k_j));
			if(ris) ris=4-ris;
			break;
		case  1:ris=mod4(esp_k_j);
			break;
		case  0:ris=0;
	}
*//*
	printf("\n esp %d\n",esp);
	avma=ltop1;
	return(esp&3);
}


//                          [    x    ]
//Funzione per calcolare    [ ------- ]
//                          [    y    ]3

short i_rbiquad1(GEN x,GEN y,long prec){
	long ltop1,r1,r2,t,esp;
	short k,ris;

	GEN lambda,yy,temp,esp_k_j,temp2,temp3;
	
	ltop1=avma;
	lambda=cgetg(3,t_COMPLEX);
	lambda[1]=lgeti(prec/2+1);
	lambda[2]=lgeti(prec/2+1);

	yy=cgetg(3,t_COMPLEX);
	yy[1]=lgeti(prec/2+1);
	yy[2]=lgeti(prec/2+1);

	temp=cgetg(3,t_COMPLEX);
	temp[1]=lgeti(prec/2+1);
	temp[2]=lgeti(prec/2+1);

	esp_k_j=cgeti(3);
	temp2=cgeti(prec/2+1);
	temp3=cgeti(prec/2+1);
	
	affii(gzero,esp_k_j);
	esp=0;
	
	if (!signe((GEN)y[1]) && !signe((GEN)y[2])) {   // verifico se al denominatore del residuo ho y= 0+0i
		if(!signe((GEN)x[2]) && is_pm1((GEN)x[1]))
			switch(signe((GEN)x[1])) {
				case -1: return(2);  // x=-1+0i
				case 1: return(0);   // x= 1+0i 
			}
		if(!signe((GEN)x[1]) && is_pm1((GEN)x[2]))
			switch(signe((GEN)x[2])) {
				case -1: return(3);  // x= 0-i
				case 1: return(1);   // x= 0+i
			}
		return(5);                        // x qualsiasi: l'esponente 5 indica il residuo biq pari a 0
	}
	
	
	gaffect(x,yy);
	gaffect(y,lambda);
	outbeaut(yy);
	outbeaut(lambda);
	
	//ho invertito x ed y per trovarmeli giusti al primo ciclo	
	i_primario(lambda,prec); 
	do{		
//		gaffect(yy,temp);
//		gaffect(lambda,yy);
//		gaffect(temp,lambda);
//		gaffect(i_mod(lambda,yy,prec),lambda);
		
		temp=i_mod(yy,lambda,prec);
		gaffect(lambda,yy);
		gaffect(temp,lambda);
		outbeaut(yy);
		outbeaut(lambda);
		printf("\n ayo!");
		if(!(signe((GEN)lambda[1]) || signe((GEN)lambda[2]))) return(5);
//		
//		while(divise((GEN)lambda[1],gtre) && divise((GEN)lambda[2],gtre)){
//      		     	diviiz((GEN)lambda[1],gtre,(GEN)lambda[1]);
//      		    	diviiz((GEN)lambda[2],gtre,(GEN)lambda[2]);
//    		    	j+=2;
//      	}
//		
//    	if(mpdivis(addii((GEN)lambda[1],(GEN)lambda[2]),gtre,temp3)){
//			subiiz(shifti(temp3,1),(GEN)lambda[2],(GEN)lambda[1]);
//			affii(temp3,(GEN)lambda[2]);
//			j++;
//		}
//		
		outbeaut((GEN)lambda[1]);
		r1=vali((GEN)lambda[1]);
		printf("\n r1 %d\n",r1);
		if(r1){
			outbeaut((GEN)lambda[2]);
			r2=vali((GEN)lambda[2]);
			printf("\n r2 %d",r2);
			if(r2){
				if(r1<r2){
					t=r1;
//					(GEN)lambda[1]=shifti((GEN)lambda[1],-r1);
//					(GEN)lambda[2]=shifti((GEN)lambda[2],-r1);
//					subiiz(esp_k_j,mulis(shifti((GEN)yy[2],-1),r1),esp_k_j);
					printf("\n dentro 1-1\n");
				}else{
					t=r2;
//					(GEN)lambda[1]=shifti((GEN)lambda[1],-r2);
//					(GEN)lambda[2]=shifti((GEN)lambda[2],-r2);
//					subiiz(esp_k_j,mulis(shifti((GEN)yy[2],-1),r2),esp_k_j);
					printf("\n dentro 1-2\n");
				}
				(GEN)lambda[1]=shifti((GEN)lambda[1],-t);
				(GEN)lambda[2]=shifti((GEN)lambda[2],-t);
				switch((((GEN)yy[2])[lgefint((GEN)yy[2])-1]) & 6) {
					case 2: switch(signe((GEN)yy[2])){
						case  1: esp=-t; break;
						case -1: esp=t; break;
						} break;
					case 4: esp=(t<<1); break;
					case 6: switch(signe((GEN)yy[2])){
						case  1: esp=t; break;
						case -1: esp=-t; break;
						} break; 
					case 0: esp=0;
				}
				printf("\n esp %d \n",esp);
			}	
			printf("\n dentro 1\n");
		}
		addsii(esp,esp_k_j,esp_k_j);
		subiiz((GEN)yy[1],gun,temp2);
		if(!(mpodd((GEN)lambda[1]) ^ mpodd((GEN)lambda[2]))){   //verifica se hanno la stessa parit�
			temp3=shifti(addii((GEN)lambda[1],(GEN)lambda[2]),-1);
			(GEN)lambda[2]=shifti(subii((GEN)lambda[2],(GEN)lambda[1]),-1);
			(GEN)lambda[1]=temp3;
			outbeaut((GEN)lambda[2]);
			addiiz(shifti(subii(temp2,addii((GEN)yy[2],gsqr((GEN)yy[2]))),-2),esp_k_j,esp_k_j);
			printf("\n dentro 2\n");
		}
		
		outbeaut(lambda);
		k=i_primario(lambda,prec);
		outbeaut(lambda);
		printf("\n k � %d \n",k);
		outbeaut(lambda);
		outbeaut(temp2);
		outbeaut(esp_k_j);
		outbeaut(lambda);
		outbeaut((GEN)lambda[1]);
		outbeaut((GEN)lambda[2]);
		printf("\n avma %d\n",avma);
		printf("\n prova %d, tipo %d %d %d\n",k+1,typ((GEN)lambda[1]),lg(lambda),lgefint(lambda[1]));
		outbeaut(addis((GEN)lambda[1],1));
		printf("\n avma %d\n",avma);
		printf("\n prova %d, tipo %d %d %d\n",k+1,typ((GEN)lambda[1]),lg(lambda),lgefint(lambda[1]));
		printf("\n avma %d\n",avma);
		outbeaut(lambda);
		outbeaut((GEN)lambda[1]);
		outbeaut((GEN)lambda[2]);
		subiiz(esp_k_j,mulii(subsi(k+1,(GEN)lambda[1]),shifti(temp2,-1)),esp_k_j);
		printf("\n mah %d\n",mod4(negi(stoi(-33))));
		outbeaut(lambda);
		outbeaut(esp_k_j);
			
		
//		if(k!=0 || j!=0)
//			addiiz(mulsi(j-(j%2)-k,modii(divii(addii(temp2,(GEN)yy[2]),gtre),gtre)),esp_k_j,esp_k_j);
//		if(j!=0)
//			addiiz(mulsi(-j,modii(divii(temp2,gtre),gtre)),esp_k_j,esp_k_j);
		
		outbeaut(lambda);
//		esp_k_j=gerepile(ltop2,avma,esp_k_j);
		outbeaut(esp_k_j);
		outbeaut(lambda);
	}while (signe((GEN)lambda[2]) || !is_pm1((GEN)lambda[1]));

//	}while(!gcmp0((GEN)lambda[2]) ||(!gcmp1((GEN)lambda[1]) && !gcmp_1((GEN)lambda[1])));     
	switch(signe(esp_k_j)){
		case -1:ris=mod4(negi(esp_k_j));
			if(ris) ris=4-ris;
			break;
		case  1:ris=mod4(esp_k_j);
			break;
		case  0:ris=0;
	}
	avma=ltop1;
	return(ris);
}



// Funzione per trovare y, a meno di un'associato, tale che Ny=x

GEN w_scomp(GEN x,long prec){
	long ltop;
	GEN ris,roots_p,alfa,beta;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	alfa=cgetg(3,t_VEC);
	alfa[1]=lgeti(prec/2+1);
	alfa[2]=lgeti(prec/2+1);
	beta=cgetg(3,t_VEC);
	beta[1]=lgeti(prec/2+1);
	beta[2]=lgeti(prec/2+1);
	
	affii(gzero,(GEN)alfa[2]);
	affii(gun,(GEN)beta[2]);
      affii(x,(GEN)alfa[1]);
      
	roots_p=rootmod(flisexpr("x^2+x+1"),x);
	mpnegz(lift((GEN)roots_p[1]),(GEN)beta[1]);
	gaffect(w_gcd(alfa,beta,prec),ris);
	avma=ltop;
	return(ris);
}

*/

// Funzione per il calcolo del simbolo di Jacobi
// con a,b interi
 	
short jacob(GEN a,GEN b,long prec){
      long ltop1;
	short m=1,flag=0;
	GEN aa,bb,c;
	aa=cgeti(prec);
	bb=cgeti(prec);
	c=cgeti(prec);
	ltop1=avma;
	affii(a,aa);
	affii(b,bb);
	do{
		avma=ltop1;
		modiiz(aa,bb,c);
	   	flag=mod8(bb);
	   	while(!mpodd(c)){
			     	affii(shifti(c,-1),c);
      		     	if(flag==3 || flag==5) m=-m;
      	}
      	if(mod4(c)==3 && mod4(bb)==3) m=-m;
		affii(bb,aa);
		affii(c,bb);
	}while (!gcmp1(c));     
	avma=ltop1;
	return(m);
}

