#include<stdlib.h>
#include"biq1-1.h"
//   Programma di test per verificare la velocit� del calcolo
//   del residuo biquadratico mediante la reciprocit� biquadratica 
//   e propriet� correlate, confrontandolo con il semplice 
//   esponenziale modulare


int main()
{
	long n,prec=3,ltop,k,memstart,time[2],time_tot,it_max=0;
	short i,j,esp_i,flag;
	int bit[10]={300,400,500,600,700,800,900,1000,1100,1200};
	GEN max,p;
 	GEN alfa,pi,biqres;  //  di tipo t_COMPLEX
 	
 	// [  alfa   ]
  	// [ ------- ]
  	// [   pi    ]4
  	
  	FILE *fp3,*fp2;	
	fp3=fopen("tempi1","a");
	fp2=fopen("simboli2","a");
	pari_init(3000000,500000);
	printf("\n\n  ** Biquadratic Residue Identification Protocol **\n\n");
	printf("     Test per il calcolo del residuo biquadratico \n\n");
	printf("Si confrontano i seguenti metodi:\n");
	printf("    * esponenziale modulare\n ");
	printf("   * reciprocita' biquadratica e proprieta' correlate \n\n\n");
	printf("\nE' possibile inserire i dati in formato esponenziale.\n\n");
	//printf("Immettere la bit-size della chiave privata (n pari):\n");
	//n=itos(lisGEN(stdin));
	printf("\nInserire il numero di iterazioni \n");
	scanf("%d",&it_max);
	for(j=0;j<10;j++){
	n=bit[j];
	printf("\n n=%d",n);
	if (n>0) prec=(long)(n/BITS_IN_LONG+3);
		
	alfa=cgetg(3,t_COMPLEX);
	alfa[1]=lgeti(prec/2+2);
	alfa[2]=lgeti(prec/2+2);
	pi=cgetg(3,t_COMPLEX);
	pi[1]=lgeti(prec/2+2);
	pi[2]=lgeti(prec/2+2);
	biqres=cgetg(3,t_COMPLEX);
	biqres[1]=lgeti(prec/2+2);
	biqres[2]=lgeti(prec/2+2);
	max=cgeti(prec/2+1);
	p=cgeti(prec+1);	

	//max � l'estremo superiore dei random
	//ogni random <max
	gaffect(gdeux,max);
	max=gpow(max,stoi(n/2-1),prec/2+1);

	memstart=avma;
	for(k=0;k<2;k++) time[k]=0;
	
      flag=1;
      timer2();
	
      for(k=0;k<it_max;k++){
	esp_i=0;
      avma=memstart;
	do{
			affii(genrand(max),(GEN)pi[1]);
			if(mpodd((GEN)pi[1])) addiiz((GEN)pi[1],gun,(GEN)pi[1]); 
			affii(genrand(max),(GEN)pi[2]);
			if(!mpodd((GEN)pi[2])) addiiz((GEN)pi[2],gun,(GEN)pi[2]); 
			addiiz(sqri((GEN)pi[1]),sqri((GEN)pi[2]),p);
			avma=memstart;
	}while((mod4(p)==3) || !isprime(p) );
	gaffect(genrand(max),(GEN)alfa[1]);  
  	gaffect(genrand(max),(GEN)alfa[2]);
  	//outbeaut(alfa);
	//outbeaut(pi);
  	timer();
	esp_i=i_rbiquad(alfa,pi,2*prec);
	time[0]=time[0]+timer();
	gaffect(i_biquad(alfa,pi,2*prec),biqres);
	time[1]=time[1]+timer();
	//switchout("simboli1");
	//outbrute(alfa);
	//outbrute(flisexpr(" xxx "));
	//outbeaut(pi);
	//outbrute(stoi(esp_i));
	//outbeaut(biqres);
	//switchout(NULL);
	//outbeaut(biqres);
	//printf("\n segni x1 %d, x2 %d\n",signe((GEN)biqres[1]),signe((GEN)biqres[2]));
	
	
	
	switch(signe((GEN)biqres[1])){
		case -1: if(esp_i!=2){
			fprintf(fp3,"***1Errore all'iterazione %d \n",k+1); 
			flag=0;
			} break;
		case  1: if(esp_i!=0){
			fprintf(fp3,"***2Errore all'iterazione %d \n",k+1); 
			flag=0;
			} break;
		case  0: switch(signe((GEN)biqres[2])){
				case  1: if(esp_i!=1){
					fprintf(fp3,"***3Errore all'iterazione %d \n",k+1); 
					flag=0;
					} break;
				case -1: if(esp_i!=3){
					fprintf(fp3,"***4Errore all'iterazione %d \n",k+1); 
					flag=0;
					} break;
		}break;
	}
      }


     	time_tot=timer2();
     	fprintf(fp3,"\nBits chiave privata  %d   con %d iterazioni",n,it_max);
	if (flag) fprintf(fp3,"\n        PERCENTUALE ERRORE 0% \n\n");
      fprintf(fp3,"\nTempo medio  calcolo con reciprocit� %f",(double)time[0]/it_max);
      fprintf(fp3,"\nTempo medio  calcolo con esponenziale %f",(double)time[1]/it_max);
	fprintf(fp3,"\n\nTempo totale calcolo con reciprocit� %d",time[0]);
	fprintf(fp3,"\nTempo totale calcolo con esponenziale %d\n",time[1]);
	fprintf(fp3,"\nRapporto esp/res  %f",(float)time[1]/time[0]);
	fprintf(fp3,"\nTempo totale esecuzione %d \n\n\n",time_tot);
	}
	fclose(fp3);
	printf("\a");
	return(1);
}
