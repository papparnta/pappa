#include<stdlib.h>
#include"biq1-1.h"
//   Programma di test per verificare la velocit� del calcolo
//   del residuo biquadratico mediante la reciprocit� biquadratica
//   e propriet� correlate, confrontandolo con il simbolo di Jacobi
//   da noi implementato e quello di PARI.
//   Nel simbolo biquadratico al numeratore elemento random di Z[i]
//   e al denominatore elemento di Z[i] (non divisibile per 1+i)
//   Nel simbolo di Jacobi al numeratore la norma del numeratore del biquadratico
//   e al denominatore la norma del denominatore utilizzato nel biquadratico.


int main()
{
	long n,prec=3,ltop,k,memstart,time[3],time_tot,it_max=0;
	short i,j,esp_i,leg,leg2;
	int bit[21]={500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000,2100,2200,2300,2400,2500},espo[6];
	GEN p,max,max2,q;
	GEN alfa,pi;  //  di tipo t_COMPLEX

	// [  alfa   ]
	// [ ------- ]
	// [   pi    ]4
	
	FILE *fp3;
	fp3=fopen("tempi3","a");
	pari_init(5000000,500000);
	printf("\n\n  ** Biquadratic Residue Identification Protocol **\n\n");
	printf("     Test per i tempi di calcolo del residuo biquadratico \n\n");
	printf("Si confrontano i seguenti:\n");
	printf("    * simbolo di Jacobi (PARI e nostra implementazione)\n ");
	printf("   * simbolo biquadratico (con reciprocit�)\n\n\n");
	printf("\nE' possibile inserire i dati in formato esponenziale.\n\n");
	//printf("Immettere la bit-size della chiave privata (n pari):\n");
	//n=itos(lisGEN(stdin));
	printf("\nInserire il numero di iterazioni \n");
	scanf("%d",&it_max);
	for(j=0;j<21;j++){
	n=bit[j];
	printf("\n n=%d",n);
	if (n>0) prec=(long)(n/BITS_IN_LONG+3);

	alfa=cgetg(3,t_COMPLEX);
	alfa[1]=lgeti(prec/2+2);
	alfa[2]=lgeti(prec/2+2);
	pi=cgetg(3,t_COMPLEX);
	pi[1]=lgeti(prec/2+2);
	pi[2]=lgeti(prec/2+2);
	max=cgeti(prec/2+1);
	max2=cgeti(prec+1);
	p=cgeti(prec+1);
	q=cgeti(prec+1);

	//max � l'estremo superiore dei random
	//ogni random <max=2^(n/2-1)
	max=gpow(gdeux,stoi(n/2),prec/2+1);

	memstart=avma;
	for(k=0;k<3;k++) time[k]=0;
	for(k=0;k<6;k++) espo[k]=0;
	
	timer2();
	
	//affii(gzero,(GEN)alfa[2]);
	for(k=0;k<it_max;k++){
		esp_i=0;
		do{
		
			avma=memstart;
			affii(genrand(max),(GEN)pi[1]);
			if(mpodd((GEN)pi[1])) addiiz((GEN)pi[1],gun,(GEN)pi[1]); 
			affii(genrand(max),(GEN)pi[2]);
			if(!mpodd((GEN)pi[2])) addiiz((GEN)pi[2],gun,(GEN)pi[2]); 
			addiiz(sqri((GEN)pi[1]),sqri((GEN)pi[2]),p);
			affii(genrand(max),(GEN)alfa[1]);
			if(mpodd((GEN)alfa[1])) addiiz((GEN)alfa[1],gun,(GEN)alfa[1]); 
			affii(genrand(max),(GEN)alfa[2]);
			if(!mpodd((GEN)alfa[2])) addiiz((GEN)alfa[2],gun,(GEN)alfa[2]); 
			addiiz(sqri((GEN)alfa[1]),sqri((GEN)alfa[2]),q);
		}while(!gcmp1(ggcd(p,q)) );
		//outbeaut(ggcd(p,q));
		//outbeaut(p);
		//outbeaut(q);
		
		//switchout("simboli2");
		//outbeaut(alfa);
		//outbeaut(pi);
		//switchout(NULL);
		
		timer();
		esp_i=i_rbiquad(alfa,pi,2*prec);

		//switchout("simboli2");
		//outbeaut(stoi(esp_i));
		//switchout(NULL);

		time[0]=time[0]+timer();
		leg2=jacob(q,p,prec);
		//printf("\n1-Leg %d\n",leg2);

		time[1]=time[1]+timer();
		leg=kronecker(q,p);
		//printf("2-Leg %d\n",leg);
		time[2]=time[2]+timer();
		espo[esp_i]++;
	}
	time_tot=timer2();
	fprintf(fp3,"\nBits chiave privata  %d   con %d iterazioni\n\n",n,it_max);
	fprintf(fp3,"\nTempo medio  calcolo simbolo biquadratico %f",(double)time[0]/it_max);
	fprintf(fp3,"\nTempo medio  calcolo simbolo Jacobi con funz di BIQ %f",(double)time[1]/it_max);
	fprintf(fp3,"\nTempo medio  calcolo simbolo Jacobi con funz di PARI %f",(double)time[2]/it_max);
	fprintf(fp3,"\n\nTempo totale calcolo simbolo biquadratico %d",time[0]);
	fprintf(fp3,"\nTempo totale calcolo simbolo Jacobi con funz di BIQ %d",time[1]);
	fprintf(fp3,"\nTempo totale calcolo simbolo Jacobi con funz di PARI %d\n",time[2]);
	fprintf(fp3,"\nRapporto Biquadratico/Jacobi(BIQ)     %f",(double)time[0]/time[1]);
	fprintf(fp3,"\nRapporto Biquadratico/Jacobi(PARI)     %f\n",(double)time[0]/time[2]);
	fprintf(fp3,"\nTempo totale esecuzione %d \n",time_tot);
	for(k=0;k<4;k++) fprintf(fp3,"\nNumero di residui pari a i^%d --> %d",k,espo[k]);
	fprintf(fp3,"\nNumero di residui pari a 0   --> %d\n\n",espo[5]);
	}
	fclose(fp3);
	printf("\a");
	return(1);
}
