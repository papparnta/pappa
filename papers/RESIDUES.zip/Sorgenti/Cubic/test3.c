#include<stdlib.h>
#include"cubic.h"
//   Programma di test per verificare la velocit� del calcolo
//   del residuo cubico mediante la reciprocit� cubica e propriet�
//   correlate, confrontandolo con il simbolo di Jacobi
//   da noi implementato e quello di PARI.
//   Nel simbolo cubico al numeratore C_i intero random
//   e al denominatore primo di Z[w]
//   Nel simbolo di Jacobi al numeratore C_i intero random
//   e al denominatore la norma del primo utilizzato nel cubico


int main()
{
	long n,prec=3,ltop,k,memstart,time[3],time_tot,it_max=0;
	short i,j,esp_w,leg,leg2;
	int bit[21]={500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000,2100,2200,2300,2400,2500},espo[6];
	GEN max,p,prod,q,max2;
 	GEN alfa,pi,cubic;  //  di tipo t_INTMOD

 	// [  alfa   ]
  	// [ ------- ]
  	// [   pi    ]3
  	FILE *fp3;
	fp3=fopen("tempi3","a");
	pari_init(1500000,500000);
	printf("\n\n  ** Cubic Residue Identification Protocol **\n\n");
	printf("     initial set-up and key construction\n\n");
	printf("\nE' possibile inserire i dati in formato esponenziale.\n\n");
	//printf("Immettere la bit-size della chiave privata (n pari):\n");
 	//n=itos(lisGEN(stdin));
	printf("\nInserire il numero di iterazioni \n");
	scanf("%d",&it_max);
	for(j=0;j<21;j++){
	n=bit[j];
	if (n>0) prec=(long)(n/BITS_IN_LONG+3);

	alfa=cgetg(3,t_VEC);
	alfa[1]=lgeti(prec/2+2);
	alfa[2]=lgeti(prec/2+2);
	pi=cgetg(3,t_VEC);
	pi[1]=lgeti(prec/2+2);
	pi[2]=lgeti(prec/2+2);
	cubic=cgetg(3,t_VEC);
	cubic[1]=lgeti(prec/2+2);
	cubic[2]=lgeti(prec/2+2);
	max=cgeti(prec/2+1);
	max2=cgeti(prec+1);
	p=cgeti(prec+1);
	q=cgeti(prec+1);
	prod=cgeti(2*prec+1);

	//max � l'estremo superiore dei random
	//ogni random <max=2^(n/2-1)
	max=gpow(gdeux,stoi(n/2-1),prec/2+1);
     	//max2 � l'estremo superiore dei random
	//ogni random <max=2^(n-1)
	max2=gpow(gdeux,stoi(n-1),prec+1);




      memstart=avma;
      for(k=0;k<3;k++) time[k]=0;
	for(k=0;k<6;k++) espo[k]=0;


      timer2();

      //affii(gzero,(GEN)alfa[2]);
	for(k=0;k<it_max;k++){
		esp_w=0;
		do{
			avma=memstart;
			affii(genrand(max),(GEN)pi[1]);
			affii(genrand(max),(GEN)pi[2]);
			addiiz(gsqr(subii((GEN)pi[1],(GEN)pi[2])),mulii((GEN)pi[1],(GEN)pi[2]),p);
		}while(divise(p,stoi(3)));
		do{
			affii(genrand(max),(GEN)alfa[1]);
			affii(genrand(max),(GEN)alfa[2]);
			//printf("\n Hello ");
			addiiz(gsqr(subii((GEN)alfa[1],(GEN)alfa[2])),mulii((GEN)alfa[1],(GEN)alfa[2]),q);
			//addiiz(sqri((GEN)alfa[1]),sqri((GEN)alfa[2]),q);
	 	}while(!gcmp1(ggcd(p,q)) );
  	  	  //switchout("tempinew3");
	      //outbrute(alfa);
      	//outbeaut(pi);
	        //switchout(NULL);
            timer();
  		esp_w=w_rcubic(alfa,pi,2*prec);

	        //switchout("tempinew3");
  		//outbrute(stoi(esp_w));
	     	//  switchout(NULL);


      	time[0]=time[0]+timer();
		//muliiz((GEN)alfa[1],p,prod);
 	      leg2=jacob(q,p,prec);
    	      //printf("\n1-Leg %d\n",leg2);

      	time[1]=time[1]+timer();
      	leg=kronecker(q,p);
	      //printf("2-Leg %d\n",leg);
    	      time[2]=time[2]+timer();
		espo[esp_w]++;
	}
     	time_tot=timer2();
     	fprintf(fp3,"\nBits chiave privata  %d   con %d iterazioni\n\n",n,it_max);

      fprintf(fp3,"\nTempo medio  calcolo simbolo cubico %f",(double)time[0]/it_max);
	fprintf(fp3,"\nTempo medio  calcolo simbolo Jacobi con funz di CUBIC %f",(double)time[1]/it_max);
	fprintf(fp3,"\nTempo medio  calcolo simbolo Jacobi con funz di PARI %f",(double)time[2]/it_max);
	fprintf(fp3,"\n\nTempo totale calcolo simbolo cubico %d",time[0]);
	fprintf(fp3,"\nTempo totale calcolo simbolo Jacobi con funz di BIQ %d",time[1]);
	fprintf(fp3,"\nTempo totale calcolo simbolo Jacobi con funz di PARI %d\n",time[2]);
	fprintf(fp3,"\nRapporto Biquadratico/Jacobi(BIQ)     %f",(double)time[0]/time[1]);
	fprintf(fp3,"\nRapporto Biquadratico/Jacobi(PARI)     %f\n",(double)time[0]/time[2]);
	fprintf(fp3,"\nTempo totale esecuzione %d \n\n\n",time_tot);
      for(k=0;k<3;k++) fprintf(fp3,"\nNumero di residui pari a i^%d --> %d",k,espo[k]);
	fprintf(fp3,"\nNumero di residui pari a 0   --> %d\n\n",espo[4]);
	}
      fclose(fp3);
	printf("\a");
	return(1);
}
