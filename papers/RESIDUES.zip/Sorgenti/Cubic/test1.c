#include<stdlib.h>
#include"cubic.h"
//   Programma di test per verificare la velocit� del calcolo
//   del residuo cubico mediante la reciprocit� cubica e propriet�
//   correlate, confrontandolo con il semplice esponenziale modulare

// Funzione per calcolare il residuo cubico tramite l'esponenziale
// x^(Ny-1/4) mod y, utilizzando il metodo dei quadrati successivi



int main()
{
	long n,prec=3,ltop,k,memstart,time[2],time_tot,it_max=0;
	short i,j,esp_w,flag;
	int bit[10]={300,400,500,600,700,800,900,1000,1100,1200};
	GEN max,p;
 	GEN alfa,pi,cubic;  //  di tipo t_INTMOD
 	
 	// [  alfa   ]
  	// [ ------- ]
  	// [   pi    ]3
  	
  	FILE *fp3;	
	fp3=fopen("tempi1","a");
	pari_init(3000000,500000);
	printf("\n\n  ** Cubic Residue Identification Protocol **\n\n");
	printf("     Test per il calcolo del residuo cubico \n\n");
	printf("Si confrontano i seguenti metodi:\n");
	printf("    * esponenziale modulare\n ");
	printf("   * reciprocita' cubica e proprieta' correlate \n\n\n");
	printf("\nE' possibile inserire i dati in formato esponenziale.\n\n");
	//printf("Immettere la bit-size della chiave privata (n pari):\n");
	//n=itos(lisGEN(stdin));
	printf("\nInserire il numero di iterazioni \n");
	scanf("%d",&it_max);
	for(j=0;j<10;j++){
	n=bit[j];
	printf("\n n=%d",n);
	if (n>0) prec=(long)(n/BITS_IN_LONG+3);
	
	alfa=cgetg(3,t_VEC);
	alfa[1]=lgeti(prec/2+2);
	alfa[2]=lgeti(prec/2+2);
	pi=cgetg(3,t_VEC);
	pi[1]=lgeti(prec/2+2);
	pi[2]=lgeti(prec/2+2);
	cubic=cgetg(3,t_VEC);
	cubic[1]=lgeti(prec/2+2);
	cubic[2]=lgeti(prec/2+2);
	max=cgeti(prec/2+1);
	p=cgeti(prec+1);	

	//max � l'estremo superiore dei random
	//ogni random <max
	gaffect(gdeux,max);
      max=gpow(max,stoi(n/2-1),prec/2+1);
	
	
	  	
	

      memstart=avma;               	
      for(k=0;k<2;k++) time[k]=0;
      flag=1;      
      timer2();
	     
      for(k=0;k<it_max;k++){
      esp_w=0;
	avma=memstart;
      do {
      	ltop=avma;
		gaffect(genrand(max),(GEN)pi[1]);
		gaffect(genrand(max),(GEN)pi[2]);
		gaffect(gadd(gpow(gsub((GEN)pi[1],(GEN)pi[2]),gdeux,prec),gmul((GEN)pi[1],(GEN)pi[2])),p);
		p=gerepile(ltop,avma,p);
	}while (!divise(subii(p,gun),stoi(3)) || !isprime(p) );
	gaffect(genrand(max),(GEN)alfa[1]);  	
  	gaffect(genrand(max),(GEN)alfa[2]);
  	
  	timer();
      esp_w=w_rcubic(alfa,pi,2*prec);
	time[0]=time[0]+timer();
	gaffect(w_cubic(alfa,pi,n,2*prec),cubic);
	time[1]=time[1]+timer();
        //switchout("tempi");
  	//outbrute(stoi(esp_w));
     	//outbeaut(cubic);
   	  //switchout(NULL);
	switch(signe((GEN)cubic[1])){
		case -1: if(esp_w!=2){
			fprintf(fp3,"***1Errore all'iterazione %d \n",k+1); 
			flag=0;
			} break;
		case  1: if(esp_w!=0){
			fprintf(fp3,"***2Errore all'iterazione %d \n",k+1); 
			flag=0;
			} break;
		case  0: 
			if(esp_w!=1){
			fprintf(fp3,"***3Errore all'iterazione %d \n",k+1); 
			flag=0;
			} break;
	}
      
      }


     	time_tot=timer2();
     	fprintf(fp3,"\nBits chiave privata  %d   con %d iterazioni\n\n",n,it_max);
      if (flag) fprintf(fp3,"\n        PERCENTUALE ERRORE 0% \n\n");
	fprintf(fp3,"\nTempo medio  calcolo con reciprocit� %f",(double)time[0]/it_max);
      fprintf(fp3,"\nTempo medio  calcolo con esponenziale %f",(double)time[1]/it_max);
	fprintf(fp3,"\n\nTempo totale calcolo con reciprocit� %d",time[0]);
	fprintf(fp3,"\nTempo totale calcolo con esponenziale %d\n",time[1]);
	fprintf(fp3,"\nRapporto rec/esp  %f",(float)time[0]/time[1]);
      fprintf(fp3,"\nTempo totale esecuzione %d \n\n\n",time_tot);
	}
	fclose(fp3);
	printf("\a");
	return(1);
}
