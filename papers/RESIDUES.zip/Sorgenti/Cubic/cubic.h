#include<stdlib.h>
#include<pari.h>


// In questa libreria x,y sono elementi di Z[w], 
// cio� sono della forma
// x=x[1]+x[2]w
// y=y[1]+y[2]w


// Funzione per il calcolo della norma di x

GEN w_norma(GEN x,long prec){
	long ltop;
      GEN ris;
      ris=cgeti(prec);
      ltop=avma;
      addiiz(gsqr(subii((GEN)x[1],(GEN)x[2])),mulii((GEN)x[1],(GEN)x[2]),ris);
      avma=ltop;
      return(ris);
}


// Funzione per il calcolo del coniugato di x

GEN w_coniug(GEN x,long prec){
	long ltop;
	GEN ris;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	subiiz((GEN)x[1],(GEN)x[2],(GEN)ris[1]);
	mpnegz((GEN)x[2],(GEN)ris[2]);
	avma=ltop;
	return(ris);
}


//  Funzione per il calcolo di x+y

GEN w_somma(GEN x,GEN y,long prec){
	long ltop;
	GEN ris;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	addiiz((GEN)x[1],(GEN)y[1],(GEN)ris[1]);
	addiiz((GEN)x[2],(GEN)y[2],(GEN)ris[2]);
	avma=ltop;
	return(ris);
}
	

//  Funzione per il calcolo di x-y

GEN w_diff(GEN x,GEN y,long prec){
	long ltop;
	GEN ris;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	subiiz((GEN)x[1],(GEN)y[1],(GEN)ris[1]);
	subiiz((GEN)x[2],(GEN)y[2],(GEN)ris[2]);
	avma=ltop;
	return(ris);
}
	

//  Funzione per il calcolo di x*y

GEN w_prod(GEN x,GEN y,long prec){
	long ltop;
	GEN ris;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec+1);
	ris[2]=lgeti(prec+1);
	ltop=avma;
	subiiz(mulii((GEN)x[1],(GEN)y[1]),mulii((GEN)x[2],(GEN)y[2]),(GEN)ris[1]);
	addiiz(mulii((GEN)x[1],(GEN)y[2]),mulii((GEN)x[2],subii((GEN)y[1],(GEN)y[2])),(GEN)ris[2]);
	avma=ltop;
	return(ris);
}


// Funzione per il calcolo di x mod y

GEN w_mod(GEN x,GEN y,long prec){
	long ltop;
	GEN ris,phi,Nx;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	Nx=cgeti(prec);
	phi=cgetg(3,t_VEC);
	phi[1]=lgeti(prec+1);
	phi[2]=lgeti(prec+1);
	
	gaffect(w_prod(x,w_coniug(y,prec),prec),phi); 
	affii(w_norma(y,prec),Nx);        //ok
	affii(gdivround((GEN)phi[1],Nx),(GEN)phi[1]);
	affii(gdivround((GEN)phi[2],Nx),(GEN)phi[2]);
	
	subiiz((GEN)x[1],subii(mulii((GEN)phi[1],(GEN)y[1]),mulii((GEN)phi[2],(GEN)y[2])),(GEN)ris[1]);
	subiiz((GEN)x[2],addii(mulii((GEN)phi[1],(GEN)y[2]),mulii((GEN)phi[2],subii((GEN)y[1],(GEN)y[2]))),(GEN)ris[2]);
	avma=ltop;
	return(ris);
}


//  Funzione per il calcolo di x/y senza resto

GEN w_div(GEN x,GEN y,long prec){
	long ltop;
	GEN ris,Nx;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	Nx=cgeti(prec);
	gaffect(w_prod(x,w_coniug(y,prec),prec),ris);
	affii(w_norma(y,prec),Nx);
	affii(gdivround((GEN)ris[1],Nx),(GEN)ris[1]);
	affii(gdivround((GEN)ris[2],Nx),(GEN)ris[2]);
	avma=ltop; 
	return(ris);
}


// gcd(x,y)                     1

GEN w_gcd(GEN x,GEN y,long prec){
	long ltop;
	GEN temp,xx,yy;
	yy=cgetg(3,t_VEC);
	yy[1]=lgeti(prec/2+1);
	yy[2]=lgeti(prec/2+1);
	ltop=avma;
	xx=cgetg(3,t_VEC);
	xx[1]=lgeti(prec/2+1);
	xx[2]=lgeti(prec/2+1);
	temp=cgetg(3,t_VEC);
	temp[1]=lgeti(prec/2+1);
	temp[2]=lgeti(prec/2+1);
	gaffect(x,xx);
	gaffect(y,temp);
	do{
		gaffect(temp,yy);
		gaffect(w_mod(xx,yy,prec),temp);
		gaffect(yy,xx);	
	}while(!gegal(temp,flisexpr("[0,0]")));
	avma=ltop;
	return(yy);
}


// Funzione che trasforma x in primario e 
// restituisce l'esponente dell'w utilizzato mod 3

short w_primario(GEN x,long prec){
	long ltop;
	GEN temp,gtre;
	ltop=avma;
	temp=cgeti(prec);
	gtre=stoi(3);
	subiiz((GEN)x[1],(GEN)x[2],temp);        // temp= a-b
	if (!gcmp0(modii((GEN)x[1],gtre)))
		if (gcmp0(modii((GEN)x[2],gtre)) && gegalgs(modii((GEN)x[1],gtre),2)){
		  	avma=ltop;
		  	return(0);
		}else if(gcmp0(modii((GEN)x[2],gtre)) && gcmp1(modii((GEN)x[1],gtre))){
			mpnegz((GEN)x[1],(GEN)x[1]);
		      mpnegz((GEN)x[2],(GEN)x[2]);
		      avma=ltop;
		      return(0);
		}
	else  if (!gcmp0(modii((GEN)x[2],gtre)))
			if (gcmp0(modii(temp,gtre)) && gegalgs(modii((GEN)x[2],gtre),2)){
				affii((GEN)x[2],(GEN)x[1]);
			      mpnegz(temp,(GEN)x[2]);
			      avma=ltop;
			      return(1);
			}else if(gcmp0(modii(temp,gtre)) && gcmp1(modii((GEN)x[2],gtre))){
				mpnegz((GEN)x[2],(GEN)x[1]);
		      	affii(temp,(GEN)x[2]);
		      	avma=ltop;
		      	return(1);
			}
	if (gegalgs(modii(temp,gtre),2)){
		affii((GEN)x[1],(GEN)x[2]);
		affii(temp,(GEN)x[1]);
		avma=ltop;
	      return(2);
	}
	if (gcmp1(modii(temp,gtre))) {
		mpnegz((GEN)x[1],(GEN)x[2]);
		mpnegz(temp,(GEN)x[1]);
		avma=ltop;
	 	return(2);
	}
	avma=ltop;	      	
	return(3);
}
                                                               

// Funzione per calcolare il residuo cubico tramite l'esponenziale
// x^(Ny-1/3) mod y, utilizzando il metodo dei quadrati successivi 

GEN w_cubic(GEN x,GEN y,long n,long prec){
	long ltop,i,memstart;
	GEN ris,b;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec+1);
	ris[2]=lgeti(prec+1);
	ltop=avma;
	b=cgeti(prec);
	divisz(subii(w_norma(y,prec),gun),3,b);
	gaffect(flisexpr("[1,0]"),ris);
	memstart=avma;
	for(i=n-1;i>=0;i--){
		avma=memstart;
		gaffect(w_mod(w_prod(ris,ris,prec),y,prec),ris);
		if (bittest(b,i)) gaffect(w_mod(w_prod(ris,x,prec),y,prec),ris);
	}	
	avma=ltop;
	return(ris);
}



//                          [    x    ]
//Funzione per calcolare    [ ------- ]
//                          [    y    ]3
	
short w_rcubic(GEN x,GEN y,long prec){
	long ltop1,ltopp,j;
	short k,ris,flag;
	
	GEN lambda,yy,temp,esp_k_j,temp2,gtre,temp3;
	ltop1=avma;
	lambda=cgetg(3,t_VEC);
	lambda[1]=lgeti(prec/2+1);
	lambda[2]=lgeti(prec/2+1);
	
	yy=cgetg(3,t_VEC);
	yy[1]=lgeti(prec/2+1);
	yy[2]=lgeti(prec/2+1);
	
	temp=cgetg(3,t_VEC);
	temp[1]=lgeti(prec/2+1);
	temp[2]=lgeti(prec/2+1);
	
	esp_k_j=cgeti(3);
	temp2=cgeti(prec/2+1);
	temp3=cgeti(prec/2+1);
	
	affii(gzero,esp_k_j);
	gtre=stoi(3);
	gaffect(x,yy);
	gaffect(y,lambda);
	
	//ho invertito x ed y per trovarmeli giusti al primo ciclo	
	w_primario(lambda,prec); 
	ltopp=avma;
	do{		
		gaffect(yy,temp);
		gaffect(lambda,yy);
		gaffect(temp,lambda);
		gaffect(w_mod(lambda,yy,prec),lambda);
		
	
		j=0;
		while(divise((GEN)lambda[1],gtre) && divise((GEN)lambda[2],gtre)){
      		     	diviiz((GEN)lambda[1],gtre,(GEN)lambda[1]);
      		    	diviiz((GEN)lambda[2],gtre,(GEN)lambda[2]);
      		    	j+=2;
      	}
      	if(mpdivis(addii((GEN)lambda[1],(GEN)lambda[2]),gtre,temp3)){
			subiiz(shifti(temp3,1),(GEN)lambda[2],(GEN)lambda[1]);
			affii(temp3,(GEN)lambda[2]);
			j++;
		
		}
	      k=w_primario(lambda,prec);
            addiiz((GEN)yy[1],gun,temp2);
            
		if(k!=0 || j!=0)
			addiiz(mulsi(j-(j%2)-k,modii(divii(addii(temp2,(GEN)yy[2]),gtre),gtre)),esp_k_j,esp_k_j);
		if(j!=0)
			addiiz(mulsi(-j,modii(divii(temp2,gtre),gtre)),esp_k_j,esp_k_j);
		esp_k_j=gerepile(ltopp,avma,esp_k_j);
	}while (!gcmp0((GEN)lambda[2]) ||(!gcmp1((GEN)lambda[1]) && !gcmp_1((GEN)lambda[1])));     
	ris=itos(modii(esp_k_j,gtre));
	avma=ltop1;
	return(ris);
}


// Funzione per trovare y, a meno di un'associato, tale che Ny=x

GEN w_scomp(GEN x,long prec){
	long ltop;
	GEN ris,roots_p,alfa,beta;
	ris=cgetg(3,t_VEC);
	ris[1]=lgeti(prec/2+1);
	ris[2]=lgeti(prec/2+1);
	ltop=avma;
	alfa=cgetg(3,t_VEC);
	alfa[1]=lgeti(prec/2+1);
	alfa[2]=lgeti(prec/2+1);
	beta=cgetg(3,t_VEC);
	beta[1]=lgeti(prec/2+1);
	beta[2]=lgeti(prec/2+1);
	
	affii(gzero,(GEN)alfa[2]);
	affii(gun,(GEN)beta[2]);
      affii(x,(GEN)alfa[1]);
      
	roots_p=rootmod(flisexpr("x^2+x+1"),x);
	mpnegz(lift((GEN)roots_p[1]),(GEN)beta[1]);
	gaffect(w_gcd(alfa,beta,prec),ris);
	avma=ltop;
	return(ris);
}


// Funzione per il calcolo del simbolo di Jacobi
// con a,b interi
 	
short jacob(GEN a,GEN b,long prec){
      long ltop1;
	short m=1,flag=0;
	
	GEN aa,bb,c;
	aa=cgeti(prec);
	bb=cgeti(prec);
	c=cgeti(prec);
	ltop1=avma;
	affii(a,aa);
	affii(b,bb);
	do{		
		avma=ltop1;
		modiiz(aa,bb,c);		
	   	flag=mod8(bb);
	   	while(!mpodd(c)){
			     	affii(shifti(c,-1),c);
      		     	if(flag==3 || flag==5) m=-m;
      	}
      	if(mod4(c)==3 && mod4(bb)==3) m=-m;
		affii(bb,aa);
		affii(c,bb);
	}while (!gcmp1(c));     
	avma=ltop1;
	return(m);
}
